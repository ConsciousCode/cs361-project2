## Setup
```bash
$ javac *.java
$ jar cfe BT.jar TestBT *.class
```

## Running
```bash
$ java -jar BT.jar
```